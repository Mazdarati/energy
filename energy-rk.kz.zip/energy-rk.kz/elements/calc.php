<div id="content">
    <!-- тут будет ajax запросы -->
    <?include("left_menu.php");?>
    <div id="important_content">
        <div id="content_text">
            <script>
            $(document).ready(function(){
                /* функция sum 
                определена ниже 
                */
                $("#sbm_cr").submit(function(){
                    $("#constructor").remove();
                    $("#info_calc").remove();
                    $("#asds").remove();
                    function outMonitor(h, v){
                        var outData = "";
                        var hor = parseInt(h);
                        var ver = parseInt(v);
                        for (var i = 0; i < hor; i++){
                            outData = outData.concat("<tr>");
                            for (var j = 0; j < ver; j++){
                                outData = outData.concat("<td>Энергия РК</td>");
                            }
                            outData = outData.concat("</tr>");
                        }
                        return outData;
                    }
                    var moduls_hor = $('#moduls_hor').val();
                    var moduls_ver = $('#moduls_ver').val();
                    var str = outMonitor(moduls_hor,moduls_ver);
                    var data = "<div id=\"constructor\"><table><tbody>"+str+"</tbody></table><div id=\"constructor_width\"><div><span>"+moduls_hor*923.4+"</span></div></div><div id=\"constructor_height\"><div><span>"+moduls_ver*520.7+"</span></div></div></div>"
                    $(this).after(data);
                    var models = $('#models').val();
                    var sources = $('#sources').val();
                    var sources_first = $('#sources_first').val();
                    var distance = $('#distance').val();
                    var controller = $('#controller').val();
                    var addedDVI = $('#addedDVI:checked').val();
                    var addedMFC = $('#addedMFC:checked').val();
                    var addedRS232 = $('#addedRS232:checked').val();
                    var addedCode = "";
                    if(addedDVI != null || addedMFC != null || addedRS232 != null){
                        addedCode = addedCode.concat("<div>Дополнительное оборудование: ");
                        if(addedDVI == '1')
                            addedCode = addedCode.concat("MFC Controller");
                        if(addedMFC == '1')
                            addedCode = addedCode.concat(" DVI Converter");
                        if(addedRS232 == '1')
                            addedCode = addedCode.concat(" RS-232 Distributor");
                        addedCode = addedCode.concat("</div>");
                    }
                    var data2 = "<div id=\"info_calc\"><div>Видеостена "+moduls_hor+"х"+moduls_ver+" на базе модулей "+models+"</div><div>Размеры 1 модуля: 923.4 x 520.7 мм.</div><div>Размеры видеостены:"+ moduls_hor*923.4+ " x "+moduls_ver*520.7+" мм.</div><div>Межпанельный зазор: 1.9 мм.</div><div>Источники сигнала ("+sources+" шт.):</div><div>"+sources_first+" – "+sources+"</div><div>Контроллер видеостены: "+controller+"</div>"+addedCode+"</div>";
                    $("#constructor").after(data2);
                    var addedCode2 = "<input type=\"hidden\" name=\"models\" value=\""+models+"\" /><input type=\"hidden\" name=\"controller\" value=\""+controller+"\" /><input type=\"hidden\" name=\"sources\" value=\""+sources+"\" /><input type=\"hidden\" name=\"moduls_hor\" value=\""+moduls_hor+"\" /><input type=\"hidden\" name=\"moduls_ver\" value=\""+moduls_ver+"\" /><input type=\"hidden\" name=\"sources_first\" value=\""+sources_first+"\" /><input type=\"hidden\" name=\"distance\" value=\""+distance+"\" /><input type=\"hidden\" name=\"addedDVI\" value=\""+addedDVI+"\" /><input type=\"hidden\" name=\"addedMFC\" value=\""+addedMFC+"\" /><input type=\"hidden\" name=\"addedRS232\" value=\""+addedRS232+"\" />";
                    var data3 = "<form id=\"asds\" method=\"post\" action=\"action/msg.php\"><p class=\"title_send_amount\">Отправить запрос на расчет стоимости:</p><table class=\"send_amount\"><tbody><tr><td>Организация*</td><td><input type=\"text\" id=\"organization\" name=\"organization\"/></td></tr><tr><td>Юридический адрес*</td><td><input type=\"text\" id=\"y_address\" name=\"y_address\"/></td></tr><tr><td>Фактический адрес*</td><td><input type=\"text\" id=\"f_address\" name=\"f_address\"/></td></tr><tr><td>Городской телефон*</td><td><input type=\"text\" id=\"g_phone\" name=\"g_phone\"/></td></tr><tr><td>ФИО контактного лица*&nbsp;&nbsp;</td><td><input type=\"text\" id=\"fio\" name=\"fio\"/></td></tr><tr><td>Мобильный телефон</td><td><input type=\"text\" id=\"m_phone\" name=\"m_phone\"/></td></tr><tr><td>E-mail*</td><td><input type=\"text\" id=\"email\" name=\"email\"/></td></tr><tr><td>Комментарий</td><td><textarea id=\"comments\" name=\"comments\"></textarea></td></tr><tr><td>Каптча</td><td><div id=\"captcha\"><img src=\"codegen.php\" height=\"70px\" width=\"258px\" /></div><div id=\"input_def\">Для ввода символов:</div><input type=\"text\" id=\"captcha_code\" name=\"captcha_code\"/></td></tr><tr><td colspan=\"2\"><input type=\"submit\" value=\"Отправить\" /></td></tr></tbody></table>"+addedCode2+"</form><div id=\"err_code\"></div>";
                    $("#info_calc").after(data3);
                    return false;
                });
                $("#asds").submit(function(){
                    alert('da');
                    var moduls_hor = $('#moduls_hor').val();
                    var moduls_ver = $('#moduls_ver').val();
                    var models = $('#models').val();
                    var sources = $('#sources').val();
                    var sources_first = $('#sources_first').val();
                    var distance = $('#distance').val();
                    var controller = $('#controller').val();
                    var addedDVI = $('#addedDVI:checked').val();
                    var addedMFC = $('#addedMFC:checked').val();
                    var addedRS232 = $('#addedRS232:checked').val();
                    
                    var organization = $('#organization').val();
                    var y_address = $('#y_address').val();
                    var f_address = $('#f_address').val();
                    var g_phone = $('#g_phone').val();
                    var fio = $('#fio').val();
                    var email = $('#email').val();
                    var comments = $('#comments').val();
                    var m_phone = $('#m_phone').val();

                    $.ajax({
                      type: "POST",
                      url: "action/msg.php",
                      data: { organization: organization, y_address: y_address, f_address: f_address, g_phone: g_phone, fio: fio, email: email, comments: comments, m_phone: m_phone, moduls_hor: moduls_hor, moduls_ver: moduls_ver, models: models, sources: sources, sources_first: sources_first, distance: distance, controller: controller, addedDVI: addedDVI, addedMFC: addedMFC, addedRS232: addedRS232 },
                      success: function(asdsa){
                        $("#err_code").append(asdsa);
                      }
                    });
                    return false;
                });
            });
            
            </script>
            <form id="sbm_cr" >
            Модель:&nbsp;
            <select name="models" id="models">
            	<option value="OLM4610">ORION OLM-4610</option>
            	<option value="OLM4650">ORION OLM-4650</option>
            	<option value="OLM4651">ORION OLM-4651</option>
            	<option value="OLM5550">ORION OLM-5550</option>
            </select>
            </p>
            <p>
            Количество модулей: по горизонтали -
            <select name="moduls_hor" id="moduls_hor">
            	<option value="1">1</option>
            	<option value="2">2</option>
            	<option value="3">3</option>
            	<option value="4">4</option>
            	<option value="5">5</option>
            	<option value="6">6</option>
            	<option value="7">7</option>
            	<option value="8">8</option>
            	<option value="9">9</option>
            	<option value="10">10</option>
            </select>
            по вертикали - 
            <select name="moduls_ver" id="moduls_ver">
            	<option value="1">1</option>
            	<option value="2">2</option>
            	<option value="3">3</option>
            	<option value="4">4</option>
            	<option value="5">5</option>
            	<option value="6">6</option>
            	<option value="7">7</option>
            	<option value="8">8</option>
            	<option value="9">9</option>
            	<option value="10">10</option>
            </select>
            </p>
            <p>
            Количество источников сигнала:
            <select name="sources" id="sources">
            	<option value="1">1</option>
            	<option value="2">2</option>
            	<option value="3">3</option>
            	<option value="4">4</option>
            	<option value="5">5</option>
            	<option value="6">6</option>
            	<option value="7">7</option>
            	<option value="8">8</option>
            	<option value="9">9</option>
            	<option value="10">10</option>
            	<option value="11">11</option>
            	<option value="12">12</option>
            </select>
            </p>
            <p>
            Интерфейс первого источника сигнала:
            <select name="sources_first" id="sources_first">
            	<option value="DVI">DVI</option>
            	<option value="HDMI">HDMI</option>
            	<option value="VGA">VGA</option>
            	<option value="Composite">Composite</option>
            	<option value="S-VIDEO">S-Video</option>
            	<option value="SDI">SDI</option>
            </select><br />
            Примерное расстояние от данного источника до видеостены(метры):
            <select name="distance" id="distance">
            	<option value="10">10</option>
            	<option value="20">20</option>
            	<option value="30">30</option>
            	<option value="40">40</option>
            	<option value="50">50</option>
            	<option value="60">60</option>
            	<option value="70">70</option>
            	<option value="80">80</option>
            	<option value="90">90</option>
            	<option value="100">100</option>
            	<option value="101">более 100</option>
            </select>
            </p>
            <p>
            Контроллер:
            <select name="controller" id="controller">
            	<option value="встроенный в модели Orion">встроенный в модели Orion</option>
            	<option value="внешний Datapath">внешний Datapath</option>
            	<option value="контроллер заказчика">контроллер заказчика</option>
            </select>
            </p>
            <p>
            Дополнительное оборудование:<br />
            <input type="checkbox" name="addedDVI" id="addedDVI" value="1" /> MFC Controller&nbsp;&nbsp;&nbsp;
            <input type="checkbox" name="addedMFC" id="addedMFC" value="1" /> DVI Converter&nbsp;&nbsp;&nbsp;
            <input type="checkbox" name="addedRS232" id="addedRS232" value="1" /> RS-232 Distributor&nbsp;&nbsp;&nbsp;
            </p>
            <p>
            <input type="submit" value="Построить" />
            </form>
        </div>
    </div>
</div>