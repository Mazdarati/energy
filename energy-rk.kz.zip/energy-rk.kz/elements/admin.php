<div id="content">
    <!-- тут будет ajax запросы -->
    <?include("left_menu.php");
    $r_m = mysql_query("SELECT * FROM menu_data");
    $rw_m = mysql_fetch_array($r_m);?>
    <div id="important_content">
        <div id="content_text">
            <?if($p == 'menu'){?>
            Добавить меню
            <form method="POST" id="addd_menu">
            	<p>
            	Русское название:<br /> <input type="text" id="title_ru_1" name="title_ru" />
            	</p>
            	<p>
            	Казахское название:<br /> <input type="text" id="title_kz_1" name="title_kz" />
            	</p>
            	<p>
            	Английское название:<br /> <input type="text" id="title_en_1" name="title_en" />
            	</p>
            	<input type="submit" value="Добавить" />
            </form>
            <?} else if($p == 'submenu'){?>
            Добавить под-меню
            <form method="POST" id="addd_submenu">
            	<select name="menu_id_2" id="menu_id_2">
                    <?
                    if($rw_m)
                    do{
                        printf("<option value=\"%s\">%s</option>",$rw_m['id'],$rw_m['title_ru']);
                    }while($rw_m = mysql_fetch_array($r_m));
                    ?>
                </select>
                <p>
            	Русское название:<br /> <input type="text" id="title_ru_2" name="title_ru" />
            	</p>
            	<p>
            	Казахское название:<br /> <input type="text" id="title_kz_2" name="title_kz" />
            	</p>
            	<p>
            	Английское название:<br /> <input type="text" id="title_en_2" name="title_en" />
            	</p>
            	<input type="submit" value="Добавить" />
            </form>
            <?} else if($p == 'subsubmenu'){?>
            Добавить под-подменю
            <script type="text/javascript" language="javascript">
            $(document).ready(function () {
                $("#menu_id_3").change(function(){
                    var id = $(this).val();
                    $("#submenu_id_3").html('<option value="0">Выбрать</option>');
                    $.ajax({
                      type: "GET",
                      url: "get_submenu_ajax.php?id=" + id,
                      success: function(data){
                        $("#submenu_id_3").append(data);
                      }
                    });
                });
            });
            </script>
            <form method="POST" id="addd_subsubmenu">
                Выберите меню:
            	<select id="menu_id_3" name="menu_id" >
                    <option>Выбери</option>
                    <?
                    if($rw_m)
                    do{
                        printf("<option value=\"%s\">%s</option>",$rw_m['id'],$rw_m['title_ru']);
                    }while($rw_m = mysql_fetch_array($r_m));
                    ?>
                </select>
                <br />Выберите под-меню:
                <select id="submenu_id_3" name="submenu_id">
                    <option>Выбери</option>
                </select>
                <p>
            	Русское название:<br /> <input type="text" id="title_ru_3" name="title_ru" />
            	</p>
            	<p>
            	Казахское название:<br /> <input type="text" id="title_kz_3" name="title_kz" />
            	</p>
            	<p>
            	Английское название:<br /> <input type="text" id="title_en_3" name="title_en" />
            	</p>
            	<input type="submit" value="Добавить" />
            </form>
            <?} else if($p == 'pages'){?>
            Добавить страницу
            <script type="text/javascript" src="js/tiny_mce.js"></script>
            <script type="text/javascript">
            	tinyMCE.init({
            		// General options
            		mode : "textareas",
            		theme : "advanced",
            		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",
            
            		// Theme options
            		theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
            		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
            		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
            		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
            		theme_advanced_toolbar_location : "top",
            		theme_advanced_toolbar_align : "left",
            		theme_advanced_statusbar_location : "bottom",
            		theme_advanced_resizing : true,
            
            		// Example content CSS (should be your site CSS)
            		// using false to ensure that the default browser settings are used for best Accessibility
            		// ACCESSIBILITY SETTINGS
            		content_css : false,
            		// Use browser preferred colors for dialogs.
            		browser_preferred_colors : true,
            		detect_highcontrast : true,
            
            		// Drop lists for link/image/media/template dialogs
            		template_external_list_url : "lists/template_list.js",
            		external_link_list_url : "lists/link_list.js",
            		external_image_list_url : "lists/image_list.js",
            		media_external_list_url : "lists/media_list.js",
            
            		// Style formats
            		style_formats : [
            			{title : 'Bold text', inline : 'b'},
            			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
            			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
            			{title : 'Example 1', inline : 'span', classes : 'example1'},
            			{title : 'Example 2', inline : 'span', classes : 'example2'},
            			{title : 'Table styles'},
            			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
            		],
            
            		// Replace values for the template plugin
            		template_replace_values : {
            			username : "Some User",
            			staffid : "991234"
            		}
            	});
            </script>
            <script>
            $(document).ready(function () {
                $("#menu_id_4").change(function(){
                    var id = $(this).val();
                    $("#submenu_id_4").html('<option value="0">Выбрать</option>');
                    $("#subsubmenu_id_4").html('');
                    $.ajax({
                      type: "GET",
                      url: "get_submenu_ajax.php?id=" + id,
                      success: function(data){
                        $("#submenu_id_4").append(data);
                      }
                    });
                });
                $("#submenu_id_4").change(function(){
                    var id = $(this).val();
                    $("#subsubmenu_id_4").html('');
                    $.ajax({
                      type: "GET",
                      url: "get_subsubmenu_ajax.php?id=" + id,
                      success: function(data){
                        $("#submenu_id_4").after(data);
                      }
                    });
                });
            });
            </script>
            <form method="POST" id="addd_page">
                Выберите меню:
            	<select id="menu_id_4" name="menu_id" >
                    <option>Выбрать</option>
                    <?
                    if($rw_m)
                    do{
                        printf("<option value=\"%s\">%s</option>",$rw_m['id'],$rw_m['title_ru']);
                    } while($rw_m = mysql_fetch_array($r_m));
                    ?>
                </select>
                <br />Выберите под-меню:
                <select id="submenu_id_4" name="submenu_id">
                    <option>Выбрать</option>
                </select>
               
                <p>
            	Русское название:<br />
            	<input type="text" name="title_ru" id="title_ru_4"/>
            	</p>
            	<p>
            	Казахское название:<br />
            	<input type="text" name="title_kz" id="title_kz_4"/>
            	</p>
            	<p>
            	Английское название:<br />
            	<input type="text" name="title_en" id="title_en_4"/>
            	</p>
            	<p>
            	Текст на русском:<br />
            	<textarea name="text_ru" id="text_ru_4"></textarea>
            	</p>
            	<p>
            	Текст на казахском:<br />
            	<textarea name="text_kz" id="text_kz_4"></textarea>
            	</p>
            	<p>
            	Текст на английском:<br />
            	<textarea name="text_en" id="text_en_4"></textarea>
            	</p>
            	<input type="submit" value="Добавить" />
            </form>
            <?} else if($p == 'subsubsubmenu'){?>
			Добавить под-под-подменю
            <script type="text/javascript" language="javascript">
            $(document).ready(function () {
                $("#menu_id_5").change(function(){
                    var id = $(this).val();
                    $("#submenu_id_5").html('<option value="0">Выбрать</option>');
                    $.ajax({
                      type: "GET",
                      url: "get_submenu_ajax.php?id=" + id,
                      success: function(data){
                        $("#submenu_id_5").append(data);
                      }
                    });
                });
				$("#submenu_id_5").change(function(){
                    var id = $(this).val();
                    $("#subsubmenu_id_5").html('');
                    $.ajax({
                      type: "GET",
                      url: "get_subsubsubmenu_ajax.php?id=" + id,
                      success: function(data){
                        $("#submenu_id_5").after(data);
                      }
                    });
                });
            });
            </script>
            <form method="POST" id="addd_subsubsubmenu">
                Выберите меню:
            	<select id="menu_id_5" name="menu_id" >
                    <option>Выбери</option>
                    <?
                    if($rw_m)
                    do{
                        printf("<option value=\"%s\">%s</option>",$rw_m['id'],$rw_m['title_ru']);
                    }while($rw_m = mysql_fetch_array($r_m));
                    ?>
                </select>
                <br />Выберите под-меню:
                <select id="submenu_id_5" name="submenu_id">
                    <option>Выбери</option>
                </select>
                <p>
            	Русское название:<br /> <input type="text" id="title_ru_5" name="title_ru" />
            	</p>
            	<p>
            	Казахское название:<br /> <input type="text" id="title_kz_5" name="title_kz" />
            	</p>
            	<p>
            	Английское название:<br /> <input type="text" id="title_en_5" name="title_en" />
            	</p>
            	<input type="submit" value="Добавить" />
            </form>
			<?} ?>
            <div id="err_code"></div>
        </div>
    </div>
</div>