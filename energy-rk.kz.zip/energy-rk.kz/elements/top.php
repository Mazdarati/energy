<body>
<div id="warp">
    <div id="header">
        <div id="logo">
            <a href="<?=$site_url;?>" title="Энергия - РК"><img src="images/logo.png" alt="Энергия - РК" title="Энергия - РК" /></a>
        </div>
        <div id="h_contact">
            <div id="phone">+7&nbsp;(727)&nbsp;246&nbsp;0420</div>
            <div id="send_letter"><a href="mailto:info@energy-rk.kz" target="_blank"><img class="msg_icon" src="images/icon/message.png" />&nbsp;<span id="send_letter_button">Отправить письмо</span></a><br /><span style="color: #888;">Skype: Energy_RK</span></div>
        </div>
        <div id="auth">
            <div><?if(isset($login)){printf("<a href=\"#\">".$login."</a>");} else {printf("<a href=\"login.php\">Войти</a>");}?></div>
        </div>
        <div id="lang">
            <div><a href="?lang=kz" <?if($lang == 'kz') echo 'class="lang_active"';?>>Kz</a></div>
            <div><a href="?lang=ru" <?if($lang == 'ru') echo 'class="lang_active"';?>>Rus</a></div>
            <div><a href="?lang=en" <?if($lang == 'en') echo 'class="lang_active"';?>>Eng</a></div>
        </div>
    </div>
    <div id="menu">
        <table id="menu_list" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                <?php
                $i = 0;
                do{
                    $i++;
                    if($i == $c_m){
                        printf("<td");
                    } else {
                        printf("<td id=\"m_border\"");
                    }
                    if($menu_id == $menu['id']) printf(' class="menu_active"');
                    printf("><a href=\"%s?m=%s&lang=%s\">%s</a></td>",$site_url,$menu['id'],$lang,$menu[$title_lang]);
                }while($menu = mysql_fetch_array($r_m));
                ?>
                </tr>
            </tbody>
        </table>
    </div>
	<div id="slider">
        <div class="slides_container">
			<?php
				printf('<img src="images/slider/1.jpg" alt="Slide 1" />');
			?>
        </div>
    </div>