<div id="content">
    <!-- тут будет ajax запросы -->
    <?include("left_menu.php");?>
    <div id="important_content">
        <div id="content_text">
            <?php
                if($menu_id == 2 && $sub_menu_id == 8 && $subsub_menu_id == 3){
                    $r_sbmenu = mysql_query("SELECT * FROM special_menu WHERE subsubmenu_id='$subsub_menu_id'",$db);
                    $sbmenu = mysql_fetch_array($r_sbmenu);
                    if($sbmenu){
                        printf("<table id=\"nav_package\"><tbody><tr>");
                        do{
                            printf("<td><a href=\"%s?m=%s&s=%s&ss=%s&sb=%s&lang=%s\">%s</a></td>",$site_url,$menu_id,$sub_menu_id,$subsub_menu_id,$sbmenu['id'],$lang,$sbmenu[$title_lang]);                      
                        }while($sbmenu = mysql_fetch_array($r_sbmenu));
                        printf("</tr></tbody></table>");
                    }
                }
            ?>
            <?PHP
            printf("%s",$page[$text_lang_page]);
            if(isset($login))printf("<div style=\"float: right; margin-top: 16px;\"><a class=\"ed_content\" href=\"edit.php?id=%s\"><img src=\"images/icon/edit.png\" />Редактировать</a><a class=\"ed_content ed_con_delete\" href=\"%s\"><img src=\"images/icon/delete.png\" />Удалить</a></div>",$page['page_id'],$page['page_id']);
            ?>
        </div>
    </div>
</div>