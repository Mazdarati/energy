<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="truebrains.kz" />
	<title><?=$title;?></title>
    <link href="images/icon/favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <link href="styles/common.css" type="text/css" rel="stylesheet" lang="text/css" />
	<link rel="stylesheet" href="styles/styleGallery.css" type="text/css" media="screen" title="prettyDropdown main stylesheet" charset="UTF-8" />
	<link rel="stylesheet" href="styles/prettyGallery.css" type="text/css" media="screen" title="prettyDropdown main stylesheet" charset="UTF-8" />
	<link rel="stylesheet" href="styles/prettyPhoto.css" type="text/css" media="screen" charset="UTF-8" />
    <script src="js/jquery.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
		
	<script src="js/prettyGallery.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/prettyPhoto.js" type="text/javascript" charset="UTF-8"></script>
	
	<script src="js/slides.min.jquery.js"></script>
    <script src="js/mu.js"></script>
	<script>
		$(function(){
			$('#slider').slides({
                randomize: true,
				play: 5000,
                generatePagination: false
			});
            $('#content_slider').slides({
                container: 'l_slider_container',
                randomize: true,
				play: 8000,
                generatePagination: false
			});
		});
	</script>
</head>
