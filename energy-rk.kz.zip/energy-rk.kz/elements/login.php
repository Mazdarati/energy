<div id="content">
    <div id="log_page">
        <div id="login_title">Войти</div>
        <div id="login_form">
            <form action="action/login.php" method="post">
                <div>
                    <table cellpadding="0" id="table_login">
                        <tbody>
                            <tr>
                                <td>Логин:</td>
                                <td><input type="text" name="login" /></td>
                            </tr>
                            <tr>
                                <td>Пароль:</td>
                                <td><input type="password" name="password" /></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div><input type="submit" value="Войти" id="sub_button_login" /></div>
            </form>
        </div>
    </div>
</div>