<div id="footer">
	<div id="copyright">© All rights reserved.</div>
    <div id="partners">
        <div>Наши партнеры:</div>
        <div><img src="images/sponsors/1.jpg" /><img src="images/sponsors/2.jpg" /><img src="images/sponsors/3.jpg" /><img src="images/sponsors/informtech.png" /><img src="images/sponsors/orion.png" /><img src="images/sponsors/4.jpg" /><img src="images/sponsors/6.jpg" /><img src="images/sponsors/5.jpg" /></div>
    </div>
    <div id="contacts">Алматы, 050060, ул. 20-линии, 39, офис 310А<br />Тел.:+7 (727) 246 04 20 / Факс: +7 (727) 246 45 55<br/>info@energy-rk.kz</div>
</div>
</div>
<script type="text/javascript" charset="utf-8">
$("a[rel^='prettyPhoto']").prettyPhoto({showTitle:false}); 
$('ul.gallery:first').prettyGallery({itemsPerPage:3, navigation:'bottom', animationSpeed:'slow'});
</script> 
</body>
</html>