<div id="submenu">
    <ul id="nav">
        <?php
        do{
            $current_id = $smenu['id'];
            $r_ssmenu = mysql_query("SELECT * FROM subsubmenu_data WHERE submenu_id='$current_id'",$db);
            $ssmenu = mysql_fetch_array($r_ssmenu);
            if($ssmenu){
				printf("<li");
				if($current_id == $sub_menu_id){
					printf(" id=\"lm_active\"");
				}
				printf("><a href=\"#\" class=\"sub\" tabindex=\"1\">%s</a><img src=\"images/icon/up.gif\" alt=\"\" /><ul class='closed'>",$smenu[$title_lang]);
				do{
					if($menu_id==3 && $current_id == 17){				
						if($lang == "ru")
							printf("<li><a href=\"calculator.php?m=3\">Калькулятор видеостены</a><li>");
						else if($lang == "en")
							printf("<li><a href=\"calculator.php?m=3\">Calculator</a><li>");
						else 
							printf("<li><a href=\"calculator.php?m=3\">Калькулятор</a><li>");
						printf("<li><a href=\"%s?m=%s&s=%s&lang=%s\">%s</a></li>",$site_url,$menu_id,$ssmenu["submenu_id"],$lang,$ssmenu[$title_lang]);
					} else
					printf("<li><a href=\"%s?m=%s&s=%s&ss=%s&lang=%s\">%s</a></li>",$site_url,$menu_id,$ssmenu["submenu_id"],$ssmenu["id"],$lang,$ssmenu[$title_lang]);
				} while($ssmenu = mysql_fetch_array($r_ssmenu));
				printf("</ul></li>");
            } else {
				printf("<li><a href=\"%s?m=%s&s=%s&lang=%s\">%s</a></li>",$site_url,$menu_id,$current_id,$lang,$smenu[$title_lang]);
            }
        }while($smenu = mysql_fetch_array($r_subm));
        ?>
    </ul>
    <div id="content_slider">
        <div class="l_slider_container">
			<?php
			if($sub_menu_id == 11){
				printf('<img src="images/slider_left/1_left.jpg" alt="Slide 1" />');
			} else
			if($sub_menu_id == 23){
				printf('<img src="images/slider_left/2_left.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 10){
				printf('<img src="images/slider_left/3_left.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 18){
				printf('<img src="images/slider_left/5_left.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 14){
				printf('<img src="images/slider_left/8_left.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 20){
				printf('<img src="images/slider_left/12_left.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 20){
				printf('<img src="images/slider_left/12_left_2.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 20){
				printf('<img src="images/slider_left/12_left_3.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 20){
				printf('<img src="images/slider_left/12_left_4.jpg" alt="Slide 1" />');
			}else
			if($sub_menu_id == 20){
				printf('<img src="images/slider_left/12_left_5.jpg" alt="Slide 1" />');
			}else
				printf('<img src="images/slider_left/2.jpg" alt="Slide 2" />');
			?>
            
        </div>
    </div>
    <?if(isset($login)){?>
    <ul id="nav">
        <li><a href="add.php?p=menu">Добавить меню</a></li>
        <li><a href="add.php?p=submenu">Добавить подменю</a></li>
        <li><a href="add.php?p=subsubmenu">Добавить подподменю</a></li>
        <li><a href="add.php?p=subsubsubmenu">Добавить подподподменю</a></li>
		<li><a href="add.php?p=pages">Добавить страничку</a></li>
    </ul>
    <?}?>
</div>