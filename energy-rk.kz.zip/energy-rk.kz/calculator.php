<?
session_start();
include("db/db.php");
//$site_url = "http://new.energy-rk.kz/index.php";
$site_url = "http://energy-rk.kz/index.php";
define('BASE_PATH',$site_url);
if(isset($_SESSION['login']) && isset($_SESSION['id'])){
    $login = $_SESSION['login'];
    $id = $_SESSION['id'];
}
$menu_id = $_GET['m'];
if(empty($menu_id)){
    unset($menu_id);
}
$sub_menu_id = $_GET['s'];
if(empty($sub_menu_id)){
    unset($sub_menu_id);
    $sub_menu_id = 0;
}

$subsub_menu_id = $_GET['ss'];
if(empty($subsub_menu_id)){
    unset($subsub_menu_id);
    $subsub_menu_id = 0;
}
$lang = $_GET['lang'];
if(empty($lang)){
    unset($lang);
    $lang = 'ru';
}
if($lang != 'ru' && $lang != 'en' && $lang != 'kz'){
    unset($lang);
    $lang = 'ru';
}
if(!is_numeric($menu_id)){
    unset($menu_id);
}
if(!is_numeric($sub_menu_id)){
    unset($sub_menu_id);
}
if(!is_numeric($subsub_menu_id)){
    unset($subsub_menu_id);
}
// Get INFO
$title_lang = "title_".$lang;
$title_lang_page = "page_title_".$lang;
$text_lang_page = "page_text_".$lang;
//main menu
$r_m = mysql_query("SELECT * FROM menu_data ORDER BY id ASC",$db);
$menu = mysql_fetch_array($r_m);
$c_m = mysql_num_rows($r_m);
if(!isset($menu_id)){
    $menu_id = $menu['id'];
}
$r_subm = mysql_query("SELECT * FROM submenu_data WHERE menu_id='$menu_id'",$db);
$smenu = mysql_fetch_array($r_subm);
$r_page = mysql_query("SELECT * FROM pages_data WHERE menu_id='$menu_id' AND submenu_id='$sub_menu_id' AND subsubmenu_id='$subsub_menu_id'",$db);
$page = mysql_fetch_array($r_page);
$title = $page[$title_lang_page];
// Include VIEW 
include("elements/header.php");
include("elements/top.php");
include("elements/calc.php");
include("elements/footer.php");
?>