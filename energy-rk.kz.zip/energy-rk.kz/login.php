<?php

/**
 * @author miracle
 * @copyright 2012
 */

include("db/db.php");
//$site_url = "http://new.energy-rk.kz/index.php";
$site_url = "http://energy-rk.kz/index.php";
define('BASE_PATH',$site_url);
$menu_id = $_GET['m'];
if(empty($menu_id)){
    unset($menu_id);
    $menu_id = 1;
}
$lang = $_GET['lang'];
if(empty($lang)){
    unset($lang);
    $lang = 'ru';
}
if($lang != 'ru' && $lang != 'en' && $lang != 'kz'){
    unset($lang);
    $lang = 'ru';
}
if(!is_numeric($menu_id)){
    unset($menu_id);
    $menu_id = 1;
}
$title_lang = "title_".$lang;
$r_m = mysql_query("SELECT * FROM menu_data ORDER BY id ASC",$db);
$menu = mysql_fetch_array($r_m);
$c_m = mysql_num_rows($r_m);
$title = "Войти в систему";

include("elements/header.php");
include("elements/top.php");
include("elements/login.php");
include("elements/footer.php");
?>