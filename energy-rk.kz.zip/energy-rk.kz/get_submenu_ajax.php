<?
    include("db/db.php");
    $menu_id = $_GET['id'];
    if(empty($menu_id)){
        unset($menu_id);
    }
    $result = mysql_query("SELECT * FROM submenu_data WHERE menu_id='$menu_id'");
    $row = mysql_fetch_array($result);
    if($row){
        do{
            printf("<option value=\"%s\">%s</option>",$row['id'],$row['title_ru']);
        }while($row = mysql_fetch_array($result));
    }
?>