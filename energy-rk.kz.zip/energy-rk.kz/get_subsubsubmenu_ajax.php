<?
    include("db/db.php");
    $submenu_id = $_GET['id'];
    if(empty($submenu_id)){
        unset($submenu_id);
    }
    $result = mysql_query("SELECT * FROM subsubmenu_data WHERE submenu_id='$submenu_id'");
    $row = mysql_fetch_array($result);
    if($row){
?>
 <br />Выберите под-подменю:
 <select id="subsubmenu_id_5" name="subsubmenu_id">
 <?
 do{
    printf("<option value=\"%s\">%s</option>",$row['id'],$row['title_ru']);
 }while($row = mysql_fetch_array($result));
?>
 </select>
 <? }?>