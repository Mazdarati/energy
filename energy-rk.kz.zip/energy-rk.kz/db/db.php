<?
//usual as default 'localhost'
$host="localhost";
//usual as default 'root'(if local server)
//$user="root";
$user="nrg";
//password
//$pwd="";
$pwd="Eh2921d75zQ5e7j";
//name table
//$name="energy";
$name="energyrk_main";
//connect with databases
$db = mysql_connect($host,$user,$pwd);
mysql_select_db($name,$db);
?>