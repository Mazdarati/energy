<?
    include("db/db.php");
    $submenu_id = $_GET['id'];
    if(empty($submenu_id)){
        unset($submenu_id);
    }
    $result = mysql_query("SELECT * FROM subsubmenu_data WHERE submenu_id='$submenu_id'");
    $row = mysql_fetch_array($result);
    if($row){
?>
 <br />Выберите под-подменю:
 <select id="subsubmenu_id_4" name="subsubmenu_id">
 <?
 do{
    printf("<option value=\"%s\">%s</option>",$row['id'],$row['title_ru']);
 }while($row = mysql_fetch_array($result));
?>
 </select>
  <script>
 $(function(){
    $("#subsubmenu_id_4").change(function(){
        var id = $(this).val();
        $("#subsubsubmenu_id_4").html('');
        $.ajax({
          type: "GET",
          url: "get_subsubsubmenu_ajax2.php?id=" + id,
          success: function(data){
            $("#subsubmenu_id_4").after(data);
          }
        });
    });
 });
 </script>
 <? }?>