<?php
session_start();
include ("../db/db.php");

if (isset($_POST['login'])) { $login = $_POST['login']; if ($login == '') { unset($login);} } 
if (isset($_POST['password'])) { $password=$_POST['password']; if ($password =='') { unset($password);} }


if (empty($login) or empty($password)) {
	exit ("Вы ввели не всю информацию, пожалуйста заполните все поля!");
}
$login = stripslashes($login);
$login = htmlspecialchars($login);

$password = stripslashes($password);
$password = htmlspecialchars($password);

$login = trim($login);
$password = trim($password);

$password = md5(md5($password)+"energy");

$result = mysql_query("SELECT * FROM users WHERE user_login='$login' AND user_password='$password'",$db); 
$myrow = mysql_fetch_array($result);
if (!$myrow) {
	exit ("Извините, введённый вами логин или пароль неверный.");
} else {
    $_SESSION['id']=$myrow['id'];
    $_SESSION['login']=$myrow['user_login'];
    echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=../index.php">';
}
?>