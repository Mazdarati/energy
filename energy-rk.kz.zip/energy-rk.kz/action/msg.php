<?php

/**
 * @author miracle
 * @copyright 2012
 */
 function check_code($code) {
    $code = trim($code);
    $array_mix = preg_split ('//', generate_code(), -1, PREG_SPLIT_NO_EMPTY);
    $m_code = preg_split ('//', $code, -1, PREG_SPLIT_NO_EMPTY);
    $result = array_intersect ($array_mix, $m_code);
    if (strlen(generate_code())!=strlen($code)) {
        return FALSE;
    }
    if (sizeof($result) == sizeof($array_mix)) {
        return TRUE;
    } else {
        return FALSE;
    }
}
function generate_code() {
    $hours = date("H");   
    $minuts = substr(date("H"), 0 , 1);
    $mouns = date("m");         
    $year_day = date("z"); 
    $str = $hours . $minuts . $mouns . $year_day; 
    $str = md5(md5($str));
	$str = strrev($str);
	$str = substr($str, 3, 6);
    $array_mix = preg_split('//', $str, -1, PREG_SPLIT_NO_EMPTY);
    srand ((float)microtime()*1000000);
    shuffle ($array_mix);
    return implode("", $array_mix);
}
if (isset($_POST['models'])) { $models = $_POST['models']; if ($models == '') { unset($models);} } 
if (isset($_POST['moduls_hor'])) { $moduls_hor = $_POST['moduls_hor']; if ($moduls_hor == '') { unset($moduls_hor);} } 
if (isset($_POST['moduls_ver'])) { $moduls_ver = $_POST['moduls_ver']; if ($moduls_hor == '') { unset($moduls_hor);} } 
if (isset($_POST['sources'])) { $sources = $_POST['sources']; if ($sources == '') { unset($sources);} } 
if (isset($_POST['sources_first'])) { $sources_first = $_POST['sources_first']; if ($sources_first == '') { unset($sources_first);} } 
if (isset($_POST['distance'])) { $distance = $_POST['distance']; if ($distance == '') { unset($distance);} } 
if (isset($_POST['controller'])) { $controller = $_POST['controller']; if ($controller == '') { unset($controller);} } 
if (isset($_POST['addedDVI'])) { $addedDVI = $_POST['addedDVI']; if ($addedDVI == '') { unset($addedDVI);} } 
if (isset($_POST['addedMFC'])) { $addedMFC = $_POST['addedMFC']; if ($addedMFC == '') { unset($addedMFC);} } 
if (isset($_POST['addedRS232'])) { $addedRS232 = $_POST['addedRS232']; if ($addedRS232 == '') { unset($addedRS232);} } 

if (isset($_POST['organization'])) { $org = $_POST['organization']; if ($org == '') { unset($org);} }
if (isset($_POST['y_address'])) { $yaddr = $_POST['y_address']; if ($yaddr == '') { unset($yaddr);} } 
if (isset($_POST['f_address'])) { $faddr = $_POST['f_address']; if ($faddr == '') { unset($faddr);} }
if (isset($_POST['g_phone'])) { $gphone = $_POST['g_phone']; if ($gphone == '') { unset($gphone);} }
if (isset($_POST['fio'])) { $fio = $_POST['fio']; if ($fio == '') { unset($fio);} } 
if (isset($_POST['m_phone'])) { $mphone = $_POST['m_phone']; if ($mphone == '') { unset($mphone);} } 
if (isset($_POST['email'])) { $email = $_POST['email']; if ($email == '') { unset($email);} }
if (isset($_POST['comments'])) { $comments = $_POST['comments']; if ($comments == '') { unset($comments);} }
if (isset($_POST['captcha_code'])) { $captcha_code = $_POST['captcha_code']; if ($captcha_code == '') { unset($captcha_code);} }
if(!empty($org) && !empty($yaddr) && !empty($faddr) && !empty($gphone) && !empty($fio) && !empty($email) && !empty($captcha_code)){
    if(!check_code($captcha_code)){
        exit('Неправильная каптча');
    } else {
        $header="Content-type: text/plain; charset=\"utf-8\"";
        $header.="From: <Energy-RK>info@energy-rk.kz";
        $header.="Subject: $subject";
        $header.="Content-type: text/plain; charset=\"utf-8\"";
        $to = 'info@energy-rk.kz';
        //$to = 'kj.mafiaboy@mail.ru';
        $message = 'Видеостена '.$moduls_hor.'х'.$moduls_ver.' на базе модулей '.$models.'
Размеры 1 модуля: 923.4 x 520.7 мм.
Размеры видеостены:'.($moduls_hor*923.4).' x '.(520.7*$moduls_ver).' мм.
Межпанельный зазор: 1.9 мм.
Источники сигнала ('.$sources.' шт.):
'.$sources_first.' – '.$sources.'
Контроллер видеостены: '.$controller;
        $message .= 'Организация: '.$org.'
Юридический адресс: '.$yaddr.'
Фактический адресс: '.$faddr.'
Городской телефон: '.$gphone.'
ФИО: '.$fio.'
Мобильный телефон: '.$mphone.'
Email: '.$email.'
Комменты'.$comments;
        $theme = 'Запрос на расчет стоимости от '.$org;
        mail($to,$theme,$message,$header);
        exit('Письмо отправлено!');
    }
} else {
    echo "Введите информацию.";
}

?>