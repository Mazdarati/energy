<?php
session_start();
include ("../db/db.php");

if (isset($_SESSION['login'])) { $login = $_SESSION['login']; if ($login == '') { unset($login);} } 
if (isset($_SESSION['id'])) { $id=$_SESSION['id']; if ($id =='') { unset($id);} }

if (empty($login) or empty($id)) {
	header("index.php");
}
function tsh($value){
    $value = trim($value);
    $value = stripslashes($value);
    $value = htmlspecialchars($value);
    return $value;
}
if (isset($_POST['title_ru'])) { $title_ru = $_POST['title_ru']; if ($title_ru == '') { unset($title_ru);} }
if (isset($_POST['title_en'])) { $title_en = $_POST['title_en']; if ($title_en == '') { unset($title_en);} } 
if (isset($_POST['title_kz'])) { $title_kz = $_POST['title_kz']; if ($title_kz == '') { unset($title_kz);} } 
if (isset($_POST['text_ru'])) { $text_ru = $_POST['text_ru']; if ($text_ru == '') { unset($text_ru);} } 
if (isset($_POST['text_en'])) { $text_en = $_POST['text_en']; if ($text_en == '') { unset($text_en);} } 
if (isset($_POST['text_kz'])) { $text_kz = $_POST['text_kz']; if ($text_kz == '') { unset($text_kz);} } 
if (isset($_POST['page_id'])) { $page_id = $_POST['page_id']; if ($page_id == '') { unset($page_id);} }

$title_ru = tsh($title_ru);
$title_en = tsh($title_en);
$title_kz = tsh($title_kz);
if(!empty($text_kz) && !empty($text_en) && !empty($text_ru) && !empty($title_kz) && !empty($title_en) && !empty($title_ru) && !empty($page_id)){
    $result = mysql_query("SELECT * FROM pages_data WHERE page_id='$page_id'",$db); 
    $myrow = mysql_fetch_array($result);
    
    if (!$myrow) {
    	exit ("Такой страницы нету.");
    } else {
        mysql_query("UPDATE pages_data SET page_title_ru='$title_ru',page_title_en='$title_en',page_title_kz='$title_kz',page_text_ru='$text_ru',page_text_kz='$text_kz',page_text_en='$text_en',page_modified=NOW() WHERE page_id='$page_id'");
        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=../index.php">';
    }
} else {
    echo "Введите информацию.";
}
?>