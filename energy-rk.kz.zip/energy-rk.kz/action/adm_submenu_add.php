<?php

/**
 * @author miracle
 * @copyright 2012
 */
session_start();
include ("../db/db.php");

if (isset($_SESSION['login'])) { $login = $_SESSION['login']; if ($login == '') { unset($login);} } 
if (isset($_SESSION['id'])) { $id=$_SESSION['id']; if ($id =='') { unset($id);} }

if (empty($login) or empty($id)) {
	header("index.php");
}
function tsh($value){
    $value = trim($value);
    $value = stripslashes($value);
    $value = htmlspecialchars($value);
    return $value;
}
if (isset($_POST['title_ru'])) { $title_ru = $_POST['title_ru']; if ($title_ru == '') { unset($title_ru);} }
if (isset($_POST['title_en'])) { $title_en = $_POST['title_en']; if ($title_en == '') { unset($title_en);} } 
if (isset($_POST['title_kz'])) { $title_kz = $_POST['title_kz']; if ($title_kz == '') { unset($title_kz);} }
if (isset($_POST['menu_id'])) { $menu_id = $_POST['menu_id']; if ($menu_id == '') { unset($menu_id);} } 
$title_ru = tsh($title_ru);
$title_en = tsh($title_en);
$title_kz = tsh($title_kz);
if(!empty($title_kz) && !empty($title_en) && !empty($title_ru) && !empty($menu_id)){
    mysql_query("INSERT INTO submenu_data (menu_id,title_ru,title_en,title_kz) VALUES($menu_id,'$title_ru','$title_en','$title_kz')");
    exit('<div style="color: green;">Добавлено!</div>');
} else {
    exit('<div style="color: red;">Введите информацию.');
}
?>