<?php

/**
 * @author miracle
 * @copyright 2012
 */
session_start();
include ("../db/db.php");

if (isset($_SESSION['login'])) { $login = $_SESSION['login']; if ($login == '') { unset($login);} } 
if (isset($_SESSION['id'])) { $id=$_SESSION['id']; if ($id =='') { unset($id);} }

if (empty($login) or empty($id)) {
	header("index.php");
}
if (isset($_POST['title_ru'])) { $title_ru = $_POST['title_ru']; if ($title_ru == '') { unset($title_ru);} }
if (isset($_POST['title_en'])) { $title_en = $_POST['title_en']; if ($title_en == '') { unset($title_en);} } 
if (isset($_POST['title_kz'])) { $title_kz = $_POST['title_kz']; if ($title_kz == '') { unset($title_kz);} } 

if(!empty($title_kz) && !empty($title_en) && !empty($title_ru)){
    mysql_query("INSERT INTO menu_data (title_ru,title_en,title_kz) VALUES('$title_ru','$title_en','$title_kz')");
    exit('<div style="color: green;">Добавлено!</div>');
} else {
    exit('<div style="color: red;">Введите информацию.');
}

?>