<?php

/**
 * @author miracle
 * @copyright 2012
 */

if (isset($_POST['name_2'])) { $name_2 = $_POST['name_2']; if ($name_2 == '') { unset($name_2);} } 
if (isset($_POST['email_2'])) { $email_2 = $_POST['email_2']; if ($email_2 == '') { unset($email_2);} } 
if (isset($_POST['theme_2'])) { $theme_2 = $_POST['theme_2']; if ($theme_2 == '') { unset($theme_2);} } 
if (isset($_POST['text_2'])) { $text_2 = $_POST['text_2']; if ($text_2 == '') { unset($text_2);} } 
if (isset($_POST['copy_2'])) { $copy_2 = $_POST['copy_2']; if ($copy_2 == '') { unset($copy_2);} } 

if(!empty($text_2) && !empty($theme_2) && !empty($email_2) && !empty($name_2)){
$header="Content-type: text/plain; charset=\"utf-8\"";
        $header.="From: <Energy-RK>info@energy-rk.kz";
        $header.="Subject: $subject";
        $header.="Content-type: text/plain; charset=\"utf-8\"";
        $to = 'info@energy-rk.kz';
        //$to = 'kj.mafiaboy@mail.ru';
        $message = 'Вопрос
Имя: '.$name_2.'
Email: '.$email_2.'
Тема: '.$theme_2.'
Текст: '.$text_2;
        $theme = 'Вопрос от '.$name_2;
        mail($to,$theme,$message,$header);
        if($copy_2  == 1){
            mail($email_2,$theme,$message,$header);
        }
        exit('Письмо отправлено!');
} else {
    exit("Введите информацию.");
}
?>