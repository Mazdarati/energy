<?php

/**
 * @author miracle
 * @copyright 2012
 */

session_start();
include ("../db/db.php");

if (isset($_SESSION['login'])) { $login = $_SESSION['login']; if ($login == '') { unset($login);} } 
if (isset($_SESSION['id'])) { $id=$_SESSION['id']; if ($id =='') { unset($id);} }

if (empty($login) or empty($id)) {
	header("index.php");
}

function tsh($value){
    $value = trim($value);
    $value = stripslashes($value);
    $value = htmlspecialchars($value);
    return $value;
}
if (isset($_POST['title_ru'])) { $title_ru = $_POST['title_ru']; if ($title_ru == '') { unset($title_ru);} }
if (isset($_POST['title_en'])) { $title_en = $_POST['title_en']; if ($title_en == '') { unset($title_en);} } 
if (isset($_POST['title_kz'])) { $title_kz = $_POST['title_kz']; if ($title_kz == '') { unset($title_kz);} }
if (isset($_POST['text_ru'])) { $text_ru = $_POST['text_ru']; if ($text_ru == '') { unset($text_ru);} } 
if (isset($_POST['text_en'])) { $text_en = $_POST['text_en']; if ($text_en == '') { unset($text_en);} } 
if (isset($_POST['text_kz'])) { $text_kz = $_POST['text_kz']; if ($text_kz == '') { unset($text_kz);} }
if (isset($_POST['menu_id'])) { $menu_id = $_POST['menu_id']; if ($menu_id == '') { unset($menu_id);} }
if (isset($_POST['submenu_id'])) { $submenu_id = $_POST['submenu_id']; if ($submenu_id == '') { unset($submenu_id);} }
if (isset($_POST['subsubmenu_id'])) { $subsubmenu_id = $_POST['subsubmenu_id']; if ($subsubmenu_id == '') { unset($subsubmenu_id);} }  
if (isset($_POST['subsubsubmenu_id'])) { $subsubsubmenu_id = $_POST['subsubsubmenu_id']; if ($subsubsubmenu_id == '') { unset($subsubsubmenu_id);} } 
$title_ru = tsh($title_ru);
$title_en = tsh($title_en);
$title_kz = tsh($title_kz);
if(!isset($submenu_id)){
    $submenu_id = 0;
}
if(!isset($subsubmenu_id)){
    $subsubmenu_id = 0;
}
if(!isset($subsubsubmenu_id)){
    $subsubsubmenu_id = 0;
}
if(!empty($title_kz) && !empty($title_en) && !empty($title_ru) && !empty($menu_id) && !empty($text_kz) && !empty($text_en) && !empty($text_ru)){
    mysql_query("INSERT INTO pages_data (menu_id,submenu_id,subsubmenu_id,subsubsubmenu_id,page_title_ru,page_title_en,page_title_kz,page_text_ru,page_text_en,page_text_kz) VALUES($menu_id,$submenu_id,$subsubmenu_id,$subsubsubmenu_id,'$title_ru','$title_en','$title_kz','$text_ru','$text_en','$text_kz')");
    exit('<div style="color: green;">Добавлено!</div>');
} else {
    exit('<div style="color: red;">Введите информацию.');
}

?>