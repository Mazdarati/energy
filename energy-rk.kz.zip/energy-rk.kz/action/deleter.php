<?php
session_start();
include ("../db/db.php");

if (isset($_SESSION['login'])) { $login = $_SESSION['login']; if ($login == '') { unset($login);} } 
if (isset($_SESSION['id'])) { $id=$_SESSION['id']; if ($id =='') { unset($id);} }

if (empty($login) or empty($id)) {
	header("index.php");
}
if (isset($_GET['page_id'])) { $page_id = $_GET['page_id']; if ($page_id == '') { unset($page_id);} }

if(!empty($page_id)){
    $result = mysql_query("SELECT * FROM pages_data WHERE page_id='$page_id'",$db); 
    $myrow = mysql_fetch_array($result);
    if (!$myrow) {
    	exit ("Такой страницы нету.");
    } else {
        mysql_query("DELETE FROM pages_data WHERE page_id='$page_id'");
        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=../index.php">';
    }
}
?>