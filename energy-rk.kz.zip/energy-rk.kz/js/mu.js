$(document).ready(function(){
	$("#nav > li > a").click(function() {
		//alert('ok');
		
	});
    /*
    $("a").click(function(e){
        e.preventDefault();
        var link = $(this).attr("href");
        $.ajax({
              type: "GET",
              url: link,
              success: function(data){
                $("html").html(data);
              }
        });
        history.pushState({title: 'title'}, 'Title', link);
    });
    */
    $(".ed_con_delete").click(function(e){
        e.preventDefault();
        var id = $(this).attr("href");
        if (confirm("Вы действительно хотите удалить страницу?")) {
            $.ajax({
              type: "GET",
              url: "../action/deleter.php?page_id=" + id,
              success: function(data){
                alert("Удалено");
              }
            });
        }
    });
    $("#addd_menu").submit(function(){
        var title_ru = $("#title_ru_1").val();
        var title_en = $("#title_en_1").val();
        var title_kz = $("#title_kz_1").val();
        $.ajax({
          type: "POST",
          url: "action/adm_menu_add.php",
          data: { title_ru: title_ru, title_en: title_en, title_kz: title_kz },
          success: function(asdsa){
            $("#err_code").append(asdsa);
          }
        });
        return false;
    });
    $("#addd_submenu").submit(function(){
        var title_ru = $("#title_ru_2").val();
        var title_en = $("#title_en_2").val();
        var title_kz = $("#title_kz_2").val();
        var menu_id = $("#menu_id_2").val();
        $.ajax({
          type: "POST",
          url: "action/adm_submenu_add.php",
          data: { title_ru: title_ru, title_en: title_en, title_kz: title_kz, menu_id: menu_id },
          success: function(asdsa){
            $("#err_code").append(asdsa);
          }
        });
        return false;
    });
    $("#addd_subsubmenu").submit(function(){
        var title_ru = $("#title_ru_3").val();
        var title_en = $("#title_en_3").val();
        var title_kz = $("#title_kz_3").val();
        var menu_id = $("#menu_id_3").val();
        var submenu_id = $("#submenu_id_3").val();
        $.ajax({
          type: "POST",
          url: "action/adm_subsubmenu_add.php",
          data: { title_ru: title_ru, title_en: title_en, title_kz: title_kz, menu_id: menu_id,submenu_id: submenu_id },
          success: function(asdsa){
            $("#err_code").append(asdsa);
          }
        });
        return false;
    });
	$("#addd_subsubsubmenu").submit(function(){
        var title_ru = $("#title_ru_5").val();
        var title_en = $("#title_en_5").val();
        var title_kz = $("#title_kz_5").val();
        var menu_id = $("#menu_id_5").val();
        var submenu_id = $("#submenu_id_5").val();
		var subsubmenu_id = $("#subsubmenu_id_5").val();
        $.ajax({
          type: "POST",
          url: "action/adm_subsubsubmenu_add.php",
          data: { title_ru: title_ru, title_en: title_en, title_kz: title_kz, menu_id: menu_id,submenu_id: submenu_id,subsubmenu_id: subsubmenu_id },
          success: function(asdsa){
            $("#err_code").append(asdsa);
          }
        });
        return false;
    });
    $("#addd_page").submit(function(){
        var title_ru = $("#title_ru_4").val();
        var title_en = $("#title_en_4").val();
        var title_kz = $("#title_kz_4").val();
        var text_ru = $("#text_ru_4").val();
        var text_en = $("#text_en_4").val();
        var text_kz = $("#text_kz_4").val();
        var menu_id = $("#menu_id_4").val();
        var submenu_id = $("#submenu_id_4").val();
        var subsubmenu_id = $("#subsubmenu_id_4").val();
        var subsubsubmenu_id = $("#subsubsubmenu_id_4").val();
        $.ajax({
          type: "POST",
          url: "action/adm_page_add.php",
          data: { title_ru: title_ru, title_en: title_en, title_kz: title_kz, menu_id: menu_id,submenu_id: submenu_id, subsubmenu_id: subsubmenu_id, subsubsubmenu_id: subsubsubmenu_id, text_ru: text_ru, text_en: text_en, text_kz: text_kz},
          success: function(asdsa){
            $("#err_code").append(asdsa);
          }
        });
        return false;
    });
});